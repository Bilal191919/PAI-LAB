# WALMART SALES FORECASTING PROJECT
## Step-by-Step Guide - Teacher Ko Dikhane Ke Liye

---

## KONSI FILE KAHAN OPEN KARO?

```
walmart_project_files/
│
├── walmart_database_SSMS.sql      ← SSMS mein open karo (SQL Server)
│
└── VS_Code/
    ├── data_pipeline.py           ← VS Code mein chalao (Python ETL)
    └── (baaki files original project se)
```

---

## STEP 1: SSMS MEIN DATABASE BANAO

1. **SSMS (SQL Server Management Studio) kholain**
2. **Connect to Server** → `localhost` ya `DESKTOP-XXXX\SQLEXPRESS`
3. **File → Open → `walmart_database_SSMS.sql`**
4. **F5 press karo** ya **Execute button dabao**
5. Yeh sab apne aap hoga:
   - `WalmartSalesForecast` database banega
   - 6 tables banenge: Stores, Features, SalesTraining, SalesTest, ModelPredictions, PipelineLog
   - 4 Views, 3 Stored Procedures
   - Sample data insert hoga
6. **Result check karo** — Messages tab mein yeh dikhega:
   ```
   [OK] Database created successfully!
   [OK] Table "Stores" created.
   [OK] Table "SalesTraining" created.
   ... (aur messages)
   [OK] Sample data inserted successfully!
   ```

---

## STEP 2: VS CODE MEIN PYTHON SETUP KARO

### VS Code kholain aur terminal mein run karo:

```bash
# Required packages install karo
pip install flask pandas numpy scikit-learn joblib xgboost pyodbc

# ya requirements.txt se
pip install -r requirements.txt
```

---

## STEP 3: DATA_PIPELINE.PY CHALAO (ETL)

1. **VS Code mein `data_pipeline.py` kholain**
2. **Line 45 check karo** - DATA_PATH aapke system ka path hona chahiye:
   ```python
   DATA_PATH = r".\data"    # ya jahan aapka data folder hai
   ```
3. **Line 48 check karo** - SQL Server name:
   ```python
   SQL_SERVER = "localhost"    # ya "DESKTOP-XXXX\SQLEXPRESS"
   ```
4. **Terminal mein run karo:**
   ```bash
   python data_pipeline.py
   ```
5. **Output aisa dikhega:**
   ```
   10:30:01 | INFO | WALMART SALES FORECASTING - ETL PIPELINE
   10:30:01 | INFO | STEP 1: DATA EXTRACTION
   10:30:02 | INFO | [OK] train.csv: 421,570 rows
   10:30:02 | INFO | [OK] stores.csv: 45 rows
   10:30:02 | INFO | [OK] features.csv: 8,190 rows
   10:30:03 | INFO | STEP 2: DATA TRANSFORMATION
   10:30:05 | INFO | STEP 3: DATA LOADING
   Loading SalesTraining: 100% (421,570 rows)
   10:35:00 | INFO | PIPELINE COMPLETE!
   ```

---

## STEP 4: FLASK APP CHALAO (Web Interface)

```bash
cd flask_app
python app.py
```

Browser mein kholain: **http://localhost:5000**

---

## STEP 5: SSMS MEIN VERIFY KARO

Pipeline chalane ke baad SSMS mein yeh queries run karo:

```sql
USE WalmartSalesForecast;

-- Kitna data aaya?
SELECT 'Stores'       AS TableName, COUNT(*) AS Rows FROM Stores
UNION ALL
SELECT 'SalesTraining', COUNT(*) FROM SalesTraining
UNION ALL
SELECT 'Features',      COUNT(*) FROM Features;

-- Pipeline log dekho
SELECT * FROM PipelineLog ORDER BY LogID DESC;

-- Top stores dekho
SELECT * FROM vw_TopStores;

-- Holiday impact dekho
SELECT * FROM vw_HolidayImpact;

-- Stored procedure test karo
EXEC sp_GetStoreSales @StoreID = 1, @Weeks = 10;
EXEC sp_GetDeptAvgSales @StoreID = 1, @DeptID = 1;
```

---

## DATABASE SCHEMA (Teacher Ko Dikhao)

```
Stores (Store PK, Type, Size)
    |
    |--- Features (FeatureID PK, Store FK, Date, Temperature, Fuel_Price, CPI, ...)
    |
    |--- SalesTraining (SaleID PK, Store FK, Dept, Date, Weekly_Sales, IsHoliday)
    |
    |--- SalesTest (TestID PK, Store FK, Dept, Date, IsHoliday)

ModelPredictions (PredictionID PK, Store, Dept, Predicted_Sales, Model_Used, ...)
PipelineLog (LogID PK, TableName, RowsInserted, Status, ...)
```

---

## PROJECT ARCHITECTURE

```
CSV Data → data_pipeline.py → SQL Server (SSMS)
                                    ↓
              train_models.py → XGBoost Model (.pkl)
                                    ↓
              Flask App (app.py) → Web Dashboard → Teacher!
```

---

## COMMON ERRORS & FIX

| Error | Fix |
|-------|-----|
| `pyodbc.Error: Data source not found` | SQL Server service start karo (Services.msc) |
| `Login failed` | SSMS mein Windows Authentication use karo |
| `File not found: train.csv` | DATA_PATH theek karo data_pipeline.py mein |
| `Module not found: xgboost` | `pip install xgboost` run karo |
| `Port 5000 already in use` | `app.run(port=5001)` karo app.py mein |

---

## TEACHER KO YEH HIGHLIGHT KARO

✅ **ETL Pipeline** — CSV → Clean → SQL Server (Professional grade)
✅ **Database Design** — 6 tables, foreign keys, indexes, views, stored procedures  
✅ **ML Model** — XGBoost, R² = 0.9977 (99.77% accurate)
✅ **22 Features** — Lag features, rolling averages, temporal features
✅ **Flask REST API** — 5+ endpoints with proper error handling
✅ **Web Dashboard** — Interactive charts, real-time predictions
✅ **Logging** — Pipeline log table mein execution history
